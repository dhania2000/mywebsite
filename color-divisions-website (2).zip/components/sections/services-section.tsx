import { Brain, BookOpen, Code, Globe, FileText, BarChart3 } from "lucide-react"

const services = [
  {
    icon: Brain,
    title: "AI Data Services",
    description: "High-quality data annotation, curation, and model training to power your AI initiatives.",
    tags: ["Data Annotation", "Data Curation", "Model Training", "HITL"],
  },
  {
    icon: BookOpen,
    title: "E-Learning Services",
    description: "End-to-end content development and production for modern digital learning experiences.",
    tags: ["Content Development", "Faculty Support", "Art Production", "LMS Integration"],
  },
  {
    icon: Code,
    title: "Technology",
    description: "Custom software solutions, cloud services, and automation to drive digital transformation.",
    tags: ["Software Development", "Cloud Services", "Web Solutions", "IT Consulting"],
  },
  {
    icon: Globe,
    title: "Localization",
    description: "Break language barriers with expert translation, transcription, and cultural adaptation.",
    tags: ["Translation", "Transcription", "Subtitling", "Voiceover"],
  },
  {
    icon: FileText,
    title: "Publishing",
    description: "Comprehensive editorial, accessibility, and conversion services for digital publishing.",
    tags: ["Editorial Services", "Accessibility", "Conversion", "Pre Press"],
  },
  {
    icon: BarChart3,
    title: "Insights",
    description: "Data-driven insights and analytics to inform strategic business decisions.",
    tags: ["Analytics", "Reporting", "Strategy", "Optimization"],
  },
]

export function ServicesSection() {
  return (
    <section id="services" className="py-20 bg-sky-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-sky-600 font-semibold">Our Services</span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mt-2 mb-4">
            Comprehensive Solutions for
            <br />
            <span className="text-sky-600">Digital Excellence</span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            From AI-powered data services to global localization, we provide end-to-end solutions to transform your
            business.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div
              key={service.title}
              className="bg-white p-6 rounded-2xl shadow-sm hover:shadow-lg transition-shadow border border-sky-100"
            >
              <div className="w-12 h-12 bg-sky-100 rounded-xl flex items-center justify-center mb-4">
                <service.icon className="w-6 h-6 text-sky-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{service.title}</h3>
              <p className="text-gray-600 mb-4">{service.description}</p>
              <div className="flex flex-wrap gap-2">
                {service.tags.map((tag) => (
                  <span key={tag} className="px-3 py-1 bg-sky-50 text-sky-700 rounded-full text-sm">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
