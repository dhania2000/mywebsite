import { BookOpen, Accessibility, RefreshCw } from "lucide-react"

const categories = [
  {
    icon: BookOpen,
    title: "Editorial Services",
    items: [
      { name: "Indexing", href: "#indexing" },
      { name: "Pre Editing", href: "#pre-editing" },
      { name: "Style Editing", href: "#style-editing" },
      { name: "Copy Editing", href: "#copy-editing" },
      { name: "Proofreading", href: "#proofreading" },
      { name: "Language Editing", href: "#language-editing" },
    ],
  },
  {
    icon: Accessibility,
    title: "Accessibility Services",
    items: [
      { name: "PPT Accessibility", href: "#ppt-accessibility" },
      { name: "PDF Accessibility", href: "#pdf-accessibility" },
      { name: "Audio Accessibility", href: "#audio-accessibility" },
      { name: "Video Accessibility", href: "#video-accessibility" },
      { name: "Testing", href: "#testing" },
      { name: "Remediation", href: "#remediation" },
    ],
  },
  {
    icon: RefreshCw,
    title: "Conversion Services",
    items: [
      { name: "PDF Conversion", href: "#pdf-conversion" },
      { name: "XML Conversion", href: "#xml-conversion" },
      { name: "ePub Conversion", href: "#epub-conversion" },
      { name: "HTML Conversion", href: "#html-conversion" },
      { name: "Word Conversion", href: "#word-conversion" },
      { name: "LMS Data Porting", href: "#lms-data-porting" },
    ],
  },
]

export function PublishingSection() {
  return (
    <section id="publishing" className="py-20 bg-amber-600 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-amber-200 font-semibold">Publishing Services</span>
          <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-4">
            Publish with
            <br />
            <span className="text-white">Precision & Impact</span>
          </h2>
          <p className="text-amber-100 max-w-2xl mx-auto">
            From editorial excellence to accessible content, we provide comprehensive publishing services for the
            digital age.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {categories.map((category) => (
            <div key={category.title} className="bg-amber-700/50 rounded-2xl p-6">
              <div className="w-12 h-12 bg-amber-500 rounded-xl flex items-center justify-center mb-4">
                <category.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold mb-4">{category.title}</h3>
              <div className="grid grid-cols-2 gap-3">
                {category.items.map((item) => (
                  <a
                    key={item.name}
                    href={item.href}
                    className="bg-amber-800/50 px-3 py-2 rounded-lg text-sm text-amber-100 hover:bg-amber-500 hover:text-white transition-colors duration-200 cursor-pointer"
                  >
                    {item.name}
                  </a>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
