import { Award, Lightbulb, Users, Globe, Shield, Heart, Quote } from "lucide-react"

const values = [
  { icon: Award, title: "Excellence", desc: "Committed to delivering the highest quality in everything we do" },
  { icon: Lightbulb, title: "Innovation", desc: "Constantly pushing boundaries with cutting-edge solutions" },
  { icon: Users, title: "Collaboration", desc: "Working together with clients to achieve shared success" },
  { icon: Globe, title: "Global Reach", desc: "Serving clients across continents with local expertise" },
  { icon: Shield, title: "Integrity", desc: "Building trust through transparency and ethical practices" },
  { icon: Heart, title: "Passion", desc: "Driven by genuine enthusiasm for our clients' success" },
]

const testimonials = [
  {
    quote:
      "Muenot transformed our data annotation process. Their accuracy and turnaround time exceeded our expectations.",
    author: "Sarah Chen",
    role: "Head of AI, TechCorp",
  },
  {
    quote: "The e-learning content they created has significantly improved our training completion rates.",
    author: "Michael Rodriguez",
    role: "L&D Director, GlobalEd",
  },
  {
    quote: "Their localization services helped us launch in 15 new markets seamlessly. Truly world-class.",
    author: "Emma Williams",
    role: "VP International, ScaleUp Inc",
  },
]

export function AboutSection() {
  return (
    <section id="about" className="py-20 bg-teal-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-teal-600 font-semibold">About Us</span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mt-2 mb-4">
            Empowering Businesses
            <br />
            <span className="text-teal-600">Around the Globe</span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            We are a global leader in AI data services, e-learning solutions, technology, and localization, helping
            businesses transform and thrive in the digital age.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {values.map((value) => (
            <div key={value.title} className="bg-white p-6 rounded-2xl shadow-sm border border-teal-100">
              <div className="w-12 h-12 bg-teal-100 rounded-xl flex items-center justify-center mb-4">
                <value.icon className="w-6 h-6 text-teal-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{value.title}</h3>
              <p className="text-gray-600 text-sm">{value.desc}</p>
            </div>
          ))}
        </div>

        <div className="bg-teal-600 rounded-2xl p-8">
          <h3 className="text-2xl font-bold text-white text-center mb-8">What Our Clients Say</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((t) => (
              <div key={t.author} className="bg-teal-700/50 p-6 rounded-xl">
                <Quote className="w-8 h-8 text-teal-300 mb-4" />
                <p className="text-white mb-4">{t.quote}</p>
                <div className="text-teal-200">
                  <div className="font-semibold">{t.author}</div>
                  <div className="text-sm">{t.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
