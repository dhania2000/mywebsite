import { Code, Globe, Cloud, Zap, Laptop, Building, CloudCog, Smartphone } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const techCategories = [
  { id: "software", label: "Software Development", icon: Code },
  { id: "web", label: "Web Solutions", icon: Globe },
  { id: "cloud", label: "Cloud Services", icon: Cloud },
  { id: "automation", label: "Automation Solutions", icon: Zap },
  { id: "consulting", label: "IT Consulting", icon: Laptop },
]

const softwareItems = [
  { icon: Code, title: "Custom Software", desc: "Bespoke applications built for your unique requirements" },
  { icon: Building, title: "Enterprise Apps", desc: "Scalable solutions for large organizations" },
  { icon: CloudCog, title: "SaaS Platforms", desc: "Cloud-based software as a service solutions" },
  { icon: Smartphone, title: "Mobile Apps", desc: "Native and cross-platform mobile applications" },
]

export function TechnologySection() {
  return (
    <section id="technology" className="py-20 bg-emerald-700 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-emerald-200 font-semibold">Technology Services</span>
          <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-4">
            Build the Future with
            <br />
            <span className="text-amber-300">Modern Technology</span>
          </h2>
          <p className="text-emerald-100 max-w-2xl mx-auto">
            From custom software development to cloud infrastructure, we deliver technology solutions that drive
            innovation and growth.
          </p>
        </div>

        <Tabs defaultValue="software" className="w-full">
          <TabsList className="flex flex-wrap justify-center gap-2 bg-transparent mb-8">
            {techCategories.map((cat) => (
              <TabsTrigger
                key={cat.id}
                value={cat.id}
                className="flex items-center gap-2 px-4 py-2 bg-emerald-800/50 data-[state=active]:bg-white data-[state=active]:text-emerald-700 rounded-full transition text-white"
              >
                <cat.icon className="w-4 h-4" />
                {cat.label}
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="software">
            <div className="bg-emerald-800/50 rounded-2xl p-8">
              <h3 className="text-2xl font-bold mb-2">Software Development</h3>
              <p className="text-emerald-200 mb-6">Custom software solutions tailored to your business needs</p>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                {softwareItems.map((item) => (
                  <div key={item.title} className="bg-emerald-900/50 p-4 rounded-xl">
                    <div className="flex items-center gap-3 mb-2">
                      <item.icon className="w-5 h-5 text-amber-300" />
                      <span className="font-semibold">{item.title}</span>
                    </div>
                    <p className="text-sm text-emerald-200">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          {["web", "cloud", "automation", "consulting"].map((tab) => (
            <TabsContent key={tab} value={tab}>
              <div className="bg-emerald-800/50 rounded-2xl p-8 text-center">
                <p className="text-emerald-200">Explore our {tab} services</p>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  )
}
