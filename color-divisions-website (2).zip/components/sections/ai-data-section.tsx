import {
  ImageIcon,
  Box,
  Tag,
  User,
  Mic,
  Video,
  Trash2,
  Database,
  CheckCircle,
  Scale,
  Sparkles,
  Star,
  Brain,
  MessageSquare,
  FileText,
  Wand2,
  ClipboardList,
  TestTube,
} from "lucide-react"

const categories = [
  {
    title: "Data Annotation",
    description: "Precise labeling for computer vision, NLP, and audio/video AI models",
    items: [
      { icon: ImageIcon, title: "Image Labeling", desc: "Precise image annotation for computer vision training" },
      { icon: Box, title: "Object Detection", desc: "Bounding boxes and polygon annotations for object recognition" },
      { icon: Tag, title: "Text Tagging", desc: "Named entity recognition and text classification" },
      { icon: User, title: "Entity Recognition", desc: "Identify and classify named entities in unstructured text" },
      { icon: Mic, title: "Audio Annotation", desc: "Speech recognition and audio event labeling" },
      { icon: Video, title: "Video Tagging", desc: "Frame-by-frame video annotation for action recognition" },
    ],
  },
  {
    title: "Data Curation",
    description: "Clean, structure, and validate your data for optimal AI performance",
    items: [
      { icon: Trash2, title: "Data Cleaning", desc: "Remove inconsistencies and errors from your datasets" },
      { icon: Database, title: "Data Structuring", desc: "Organize unstructured data into usable formats" },
      { icon: CheckCircle, title: "Data Validation", desc: "Ensure data accuracy and quality standards" },
      { icon: Scale, title: "Bias Review", desc: "Identify and mitigate bias in training data" },
      { icon: Sparkles, title: "Metadata Enrichment", desc: "Add contextual information to enhance data value" },
      { icon: Star, title: "Quality Scoring", desc: "Rate and rank data quality for prioritization" },
    ],
  },
  {
    title: "Model Training Support",
    description: "Comprehensive training data and human feedback for AI models",
    items: [
      { icon: Brain, title: "Training Datasets", desc: "Curated datasets optimized for model training" },
      { icon: MessageSquare, title: "RLHF Support", desc: "Reinforcement learning from human feedback" },
      { icon: FileText, title: "Instruction Data", desc: "High-quality instruction-following datasets" },
      { icon: Wand2, title: "Synthetic Data", desc: "AI-generated data to augment training sets" },
      { icon: ClipboardList, title: "Prompt Data", desc: "Diverse prompts for language model fine-tuning" },
      { icon: TestTube, title: "Evaluation Sets", desc: "Benchmark datasets for model performance testing" },
    ],
  },
]

export function AIDataSection() {
  return (
    <section id="ai-data" className="py-20 bg-indigo-700 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-indigo-200 font-semibold">AI Data Services</span>
          <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-4">
            Fuel Your AI with
            <br />
            <span className="text-lime-300">Quality Data</span>
          </h2>
          <p className="text-indigo-100 max-w-2xl mx-auto">
            From data annotation to model training, we provide end-to-end data services to power your machine learning
            initiatives.
          </p>
        </div>

        <div className="space-y-12">
          {categories.map((category) => (
            <div key={category.title} className="bg-indigo-800/50 rounded-2xl p-8">
              <h3 className="text-2xl font-bold mb-2">{category.title}</h3>
              <p className="text-indigo-200 mb-6">{category.description}</p>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {category.items.map((item) => (
                  <div key={item.title} className="bg-indigo-900/50 p-4 rounded-xl">
                    <div className="flex items-center gap-3 mb-2">
                      <item.icon className="w-5 h-5 text-lime-300" />
                      <span className="font-semibold">{item.title}</span>
                    </div>
                    <p className="text-sm text-indigo-200">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
