import { PenTool, Film, Settings, Palette, Play, Users } from "lucide-react"

const sections = [
  {
    icon: PenTool,
    title: "Content Development",
    description: "Create engaging digital learning content across multiple formats",
    items: [
      "Alt Text Creation",
      "Animation Design",
      "Creative Art",
      "Instructional Design",
      "Assessment Writing",
      "Digital Marketing Content",
    ],
  },
  {
    icon: Film,
    title: "Content Production",
    description: "Professional production services for educational materials",
    items: [
      "Cover Design",
      "Quality Control",
      "LaTeX Composition",
      "InDesign Composition",
      "Template Creation",
      "Layout Design",
    ],
  },
  {
    icon: Settings,
    title: "Content Operations",
    description: "Streamlined operations for content management and delivery",
    items: ["Testing & QA", "Indexing", "Translation", "Data Curation", "Script Tagging", "Content Review"],
  },
  {
    icon: Palette,
    title: "Art Production",
    description: "Visual design and art creation for learning materials",
    items: ["Illustration", "Infographics", "Icon Design", "Photo Editing", "Vector Graphics", "Brand Assets"],
  },
  {
    icon: Play,
    title: "Video & Audio",
    description: "Multimedia production for immersive learning experiences",
    items: ["Video Editing", "Video Creation", "Audio Recording", "Voiceover", "Animation", "Motion Graphics"],
  },
  {
    icon: Users,
    title: "Faculty Support",
    description: "Dedicated support for educators and course creators",
    items: ["Course Setup", "LMS Integration", "Training", "Technical Support", "Resource Management", "Analytics"],
  },
]

export function ELearningSection() {
  return (
    <section id="elearning" className="py-20 bg-rose-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-rose-600 font-semibold">E-Learning Services</span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mt-2 mb-4">
            Transform Learning with
            <br />
            <span className="text-rose-600">Digital Excellence</span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Comprehensive e-learning solutions from content creation to delivery, helping educators and organizations
            create impactful learning experiences.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sections.map((section) => (
            <div key={section.title} className="bg-white p-6 rounded-2xl shadow-sm border border-rose-100">
              <div className="w-12 h-12 bg-rose-100 rounded-xl flex items-center justify-center mb-4">
                <section.icon className="w-6 h-6 text-rose-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{section.title}</h3>
              <p className="text-gray-600 mb-4 text-sm">{section.description}</p>
              <ul className="space-y-2">
                {section.items.map((item) => (
                  <li key={item} className="flex items-center gap-2 text-sm text-gray-700">
                    <div className="w-1.5 h-1.5 bg-rose-400 rounded-full" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
