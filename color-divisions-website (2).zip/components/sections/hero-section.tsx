import { Button } from "@/components/ui/button"
import { Play } from "lucide-react"

export function HeroSection() {
  return (
    <section id="home" className="pt-24 pb-16 bg-gradient-to-br from-blue-800 via-slate-700 to-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <span className="inline-block px-4 py-2 bg-white/20 rounded-full text-sm font-medium mb-6">
            Transforming Businesses Globally
          </span>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-balance">
            Powering the Future with
            <br />
            <span className="text-cyan-300">AI & Digital Solutions</span>
          </h1>
          <p className="text-lg md:text-xl text-white/90 max-w-3xl mx-auto mb-8">
            Comprehensive AI Data Services, E-Learning Solutions, Technology, Localization, and Publishing services
            tailored for your success.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" className="bg-white text-blue-800 hover:bg-gray-100">
              Explore Services
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/20 bg-transparent">
              <Play className="w-4 h-4 mr-2" /> Watch Demo
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16">
          {[
            { value: "500+", label: "Global Clients" },
            { value: "50M+", label: "Data Points Processed" },
            { value: "100+", label: "Languages Supported" },
            { value: "99.9%", label: "Accuracy Rate" },
          ].map((stat) => (
            <div key={stat.label} className="text-center p-6 bg-white/10 rounded-xl backdrop-blur-sm">
              <div className="text-3xl md:text-4xl font-bold text-cyan-300">{stat.value}</div>
              <div className="text-white/80 mt-2">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
