import { Button } from "@/components/ui/button"
import { Phone, Shield, Award, Clock } from "lucide-react"

export function CTASection() {
  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-violet-900 via-purple-900 to-fuchsia-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <span className="inline-block px-4 py-2 bg-fuchsia-500/20 text-fuchsia-300 rounded-full text-sm font-medium mb-6">
          Ready to Transform Your Business?
        </span>
        <h2 className="text-3xl md:text-5xl font-bold mb-6 text-balance">
          Let's Build Something
          <br />
          <span className="text-fuchsia-400">Extraordinary Together</span>
        </h2>
        <p className="text-gray-300 max-w-2xl mx-auto mb-8">
          Whether you need AI data services, e-learning solutions, or digital transformation, our team is ready to help
          you achieve your goals.
        </p>
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          <Button size="lg" className="bg-fuchsia-500 hover:bg-fuchsia-600">
            Contact Us
          </Button>
          <Button size="lg" variant="outline" className="border-gray-600 text-white hover:bg-gray-800 bg-transparent">
            <Phone className="w-4 h-4 mr-2" /> Schedule a Call
          </Button>
        </div>

        <p className="text-gray-500 mb-6">Trusted by leading organizations worldwide</p>
        <div className="flex flex-wrap justify-center gap-6">
          {[
            { icon: Shield, label: "Enterprise Ready" },
            { icon: Award, label: "ISO Certified" },
            { icon: Shield, label: "GDPR Compliant" },
            { icon: Clock, label: "24/7 Support" },
          ].map((badge) => (
            <div key={badge.label} className="flex items-center gap-2 text-gray-400">
              <badge.icon className="w-5 h-5" />
              <span>{badge.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
