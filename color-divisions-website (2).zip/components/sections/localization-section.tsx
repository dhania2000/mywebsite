import { Languages, FileAudio, Subtitles, Mic2, CheckCircle2 } from "lucide-react"

const stats = [
  { value: "100+", label: "Languages" },
  { value: "50+", label: "Countries" },
  { value: "500+", label: "Native Linguists" },
  { value: "99.5%", label: "Accuracy Rate" },
]

const services = [
  {
    icon: Languages,
    title: "Translation",
    description: "Professional translation across 100+ languages",
    items: [
      "Document Localization",
      "Website Localization",
      "App Localization",
      "Marketing Content",
      "Legal Documents",
      "Technical Manuals",
    ],
  },
  {
    icon: FileAudio,
    title: "Transcription",
    description: "Accurate transcription for all media types",
    items: [
      "Audio Transcription",
      "Video Transcription",
      "Multilingual Transcripts",
      "Meeting Notes",
      "Interview Transcripts",
      "Podcast Transcription",
    ],
  },
  {
    icon: Subtitles,
    title: "Subtitling",
    description: "Professional subtitles for global audiences",
    items: [
      "Closed Captions",
      "Multilingual Subtitles",
      "Subtitle Sync",
      "SDH Subtitles",
      "Forced Narratives",
      "Subtitle Styling",
    ],
  },
  {
    icon: Mic2,
    title: "Voiceover",
    description: "Native voice talent for authentic audio",
    items: ["Dubbing", "Narration Recording", "Localized Audio", "Character Voices", "Commercial VO", "E-Learning VO"],
  },
  {
    icon: CheckCircle2,
    title: "Linguistic QA",
    description: "Quality assurance for linguistic accuracy",
    items: [
      "Proofreading",
      "Localization Testing",
      "Cultural Review",
      "Terminology Check",
      "Style Guide Compliance",
      "Context Validation",
    ],
  },
]

export function LocalizationSection() {
  return (
    <section id="localization" className="py-20 bg-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <span className="text-purple-600 font-semibold">Localization Services</span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mt-2 mb-4">
            Speak to the World in
            <br />
            <span className="text-purple-600">Every Language</span>
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Break language barriers and connect with global audiences through expert translation, transcription, and
            cultural adaptation services.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {stats.map((stat) => (
            <div key={stat.label} className="bg-purple-600 text-white p-6 rounded-xl text-center">
              <div className="text-3xl font-bold">{stat.value}</div>
              <div className="text-purple-100 mt-1">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <div key={service.title} className="bg-white p-6 rounded-2xl shadow-sm border border-purple-100">
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-4">
                <service.icon className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{service.title}</h3>
              <p className="text-gray-600 mb-4 text-sm">{service.description}</p>
              <div className="flex flex-wrap gap-2">
                {service.items.map((item) => (
                  <span key={item} className="px-2 py-1 bg-purple-50 text-purple-700 rounded text-xs">
                    {item}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
