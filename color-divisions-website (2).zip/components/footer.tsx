import Link from "next/link"
import Image from "next/image"
import { MapPin, Headphones, Users, Monitor, Mail, Phone, Facebook, Youtube, Twitter, Linkedin } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-[#0a0a1a] text-gray-300">
      <div className="h-1 bg-gradient-to-r from-blue-600 via-blue-500 to-blue-600" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col md:flex-row md:items-start gap-6 mb-12">
          <Link href="#home" className="flex-shrink-0">
            <Image
              src="/images/blue-logo-with-name-removebg-preview.png"
              alt="Muenot - Infinite Learning, Endless Possibilities"
              width={200}
              height={50}
              className="h-12 w-auto"
            />
          </Link>
          <p className="text-gray-400 md:ml-8 max-w-xl">
            Leveraging our tech-driven expertise to streamline workforce training and deliver scalable digital
            solutions.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Offices Column */}
          <div>
            <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-red-500" />
              Offices
            </h4>
            <div className="space-y-4 text-sm">
              <div>
                <p className="text-white font-medium">India</p>
                <p className="text-gray-400">56,Mukhya Sodala,Shyam Nagar, Jaipur</p>
              </div>
              <div>
                <p className="text-white font-medium">India</p>
                <p className="text-gray-400">Tal , Jhunjhunu , Rajasthan, 333026</p>
              </div>
              <div className="flex items-center gap-2 text-gray-400">
                <Mail className="w-4 h-4" />
                <a href="mailto:info@muenot.com" className="hover:text-white transition">
                  info@muenot.com
                </a>
              </div>
            </div>
          </div>

          {/* Get in Touch Column */}
          <div>
            <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
              <Headphones className="w-5 h-5 text-blue-500" />
              Get in Touch
            </h4>
            <div className="space-y-4 text-sm">
              <div>
                <p className="text-white font-medium">For Sales / Business Development</p>
                <div className="flex items-center gap-2 text-gray-400 mt-1">
                  <span className="text-lg">🇮🇳</span>
                  <span>+91-6377809826</span>
                </div>
              </div>
              <div>
                <p className="text-white font-medium">For HR & Job Opportunities</p>
                <div className="flex items-center gap-2 text-gray-400 mt-1">
                  <Phone className="w-4 h-4" />
                  <span>6377809826</span>
                </div>
                <div className="flex items-center gap-2 text-gray-400 mt-1">
                  <Mail className="w-4 h-4" />
                  <a href="mailto:careers@muenot.com" className="hover:text-white transition">
                    careers@muenot.com
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* About Us Column */}
          <div>
            <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
              <Users className="w-5 h-5 text-yellow-500" />
              About Us
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="#about" className="text-gray-400 hover:text-white transition">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="#contact" className="text-gray-400 hover:text-white transition">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="#services" className="text-gray-400 hover:text-white transition">
                  Our Services
                </Link>
              </li>
              <li>
                <Link href="#home" className="text-gray-400 hover:text-white transition">
                  Our Clients
                </Link>
              </li>
            </ul>
          </div>

          {/* Other Pages Column */}
          <div>
            <h4 className="text-white font-semibold mb-4 flex items-center gap-2">
              <Monitor className="w-5 h-5 text-blue-500" />
              Services
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="#ai-data" className="text-gray-400 hover:text-white transition">
                  AI Data Services
                </Link>
              </li>
              <li>
                <Link href="#elearning" className="text-gray-400 hover:text-white transition">
                  E-Learning
                </Link>
              </li>
              <li>
                <Link href="#technology" className="text-gray-400 hover:text-white transition">
                  Technology
                </Link>
              </li>
              <li>
                <Link href="#localization" className="text-gray-400 hover:text-white transition">
                  Localization
                </Link>
              </li>
              <li>
                <Link href="#publishing" className="text-gray-400 hover:text-white transition">
                  Publishing
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center justify-center md:justify-end gap-4 order-1 md:order-2">
              <span className="text-gray-400 text-sm">Join Us On</span>
              <Link href="#" className="text-blue-500 hover:text-blue-400 transition">
                <Facebook className="w-5 h-5" />
              </Link>
              <Link href="#" className="text-blue-500 hover:text-blue-400 transition">
                <Youtube className="w-5 h-5" />
              </Link>
              <Link href="#" className="text-blue-500 hover:text-blue-400 transition">
                <Twitter className="w-5 h-5" />
              </Link>
              <Link href="#" className="text-blue-500 hover:text-blue-400 transition">
                <Linkedin className="w-5 h-5" />
              </Link>
            </div>
            <p className="text-gray-400 text-sm text-center md:text-left order-2 md:order-1">
              All Rights Reserved by Muenot | Copyright © 2020-2026 Www.muenot.com
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
