"use client"

import type React from "react"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Menu, X, ChevronDown } from "lucide-react"
import { useState } from "react"

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [servicesOpen, setServicesOpen] = useState(false)

  const handleScroll = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault()
    const element = document.querySelector(href)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
    setIsOpen(false)
    setServicesOpen(false)
  }

  const serviceItems = [
    { label: "AI Data", href: "#ai-data" },
    { label: "E-Learning", href: "#elearning" },
    { label: "Technology", href: "#technology" },
    { label: "Localization", href: "#localization" },
    { label: "Publishing", href: "#publishing" },
  ]

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center h-16">
          <div className="flex-1">
            <Link href="/" className="block">
              <Image
                src="/images/blue-logo-with-name-removebg-preview.png"
                alt="Muenot - Infinite Learning, Endless Possibilities"
                width={150}
                height={50}
                className="h-10 w-auto"
              />
            </Link>
          </div>

          <div className="hidden md:flex items-center justify-center gap-8">
            <div className="relative">
              <button
                onClick={() => setServicesOpen(!servicesOpen)}
                onMouseEnter={() => setServicesOpen(true)}
                className="flex items-center gap-1 text-gray-600 hover:text-gray-900 transition"
              >
                Services
                <ChevronDown className={`w-4 h-4 transition-transform ${servicesOpen ? "rotate-180" : ""}`} />
              </button>

              {servicesOpen && (
                <div
                  className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-2"
                  onMouseLeave={() => setServicesOpen(false)}
                >
                  {serviceItems.map((item) => (
                    <a
                      key={item.href}
                      href={item.href}
                      onClick={(e) => handleScroll(e, item.href)}
                      className="block px-4 py-2 text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition"
                    >
                      {item.label}
                    </a>
                  ))}
                </div>
              )}
            </div>

            <a
              href="#about"
              onClick={(e) => handleScroll(e, "#about")}
              className="text-gray-600 hover:text-gray-900 transition"
            >
              About
            </a>
          </div>

          <div className="hidden md:flex flex-1 justify-end">
            <Button onClick={() => document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" })}>
              Contact Us
            </Button>
          </div>

          <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X /> : <Menu />}
          </button>
        </div>

        {isOpen && (
          <div className="md:hidden py-4 space-y-2">
            <button
              onClick={() => setServicesOpen(!servicesOpen)}
              className="flex items-center justify-between w-full text-gray-600 hover:text-gray-900 py-2"
            >
              Services
              <ChevronDown className={`w-4 h-4 transition-transform ${servicesOpen ? "rotate-180" : ""}`} />
            </button>

            {servicesOpen && (
              <div className="pl-4 space-y-2 border-l-2 border-gray-200 ml-2">
                {serviceItems.map((item) => (
                  <a
                    key={item.href}
                    href={item.href}
                    onClick={(e) => handleScroll(e, item.href)}
                    className="block text-gray-600 hover:text-gray-900 py-1"
                  >
                    {item.label}
                  </a>
                ))}
              </div>
            )}

            <a
              href="#about"
              onClick={(e) => handleScroll(e, "#about")}
              className="block text-gray-600 hover:text-gray-900 py-2"
            >
              About
            </a>
            <Button
              className="w-full"
              onClick={() => {
                document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" })
                setIsOpen(false)
              }}
            >
              Contact Us
            </Button>
          </div>
        )}
      </div>
    </nav>
  )
}
