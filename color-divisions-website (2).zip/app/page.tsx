import { HeroSection } from "@/components/sections/hero-section"
import { ServicesSection } from "@/components/sections/services-section"
import { AIDataSection } from "@/components/sections/ai-data-section"
import { ELearningSection } from "@/components/sections/elearning-section"
import { TechnologySection } from "@/components/sections/technology-section"
import { LocalizationSection } from "@/components/sections/localization-section"
import { PublishingSection } from "@/components/sections/publishing-section"
import { AboutSection } from "@/components/sections/about-section"
import { CTASection } from "@/components/sections/cta-section"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <HeroSection />
      <ServicesSection />
      <AIDataSection />
      <ELearningSection />
      <TechnologySection />
      <LocalizationSection />
      <PublishingSection />
      <AboutSection />
      <CTASection />
      <Footer />
    </main>
  )
}
